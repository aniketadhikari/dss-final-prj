/* Delcare class level variables

model will be used throughout the JS to build the model more dynmaically

*/


let model = {};
model.modelName = "HandsOn-Transportation";
model.modelType = "optimization";

async function btnClick() {
    await buildModel();
    //Display the Model as JSON on page
    document.getElementById("submitBody").innerHTML = JSON.stringify(model, null, 4);

    let results = await Optimize();
    //Display the Result as JSON on page
    document.getElementById("result").innerHTML = JSON.stringify(results, null, 4);

    //Display the results on the page.
    displayResults(results);

    //display Costs
    document.getElementById("deliveryCost").innerHTML = CurrencyFormat(results.obj.data[0][0]);

}



function getNextStoreId() {
    //This function gets the next store ID by adding 1 to the last store found
    let stores = getStores();
    let lastStore = stores[stores.length - 1];

    let lastStoreId = lastStore.dataset.store;

    let nextStoreId = "S" + (Number(lastStoreId.substring(1)) + 1);

    return nextStoreId;

}
//warehouse adding code not working
function getWarehouses() {
    //This function pulls all the stores
    let warehouse = Array.from(document.getElementsByClassName("bakery"));
    return warehouse;
}
//not working
function getNextWarehouseId() {
    //This function gets the next store ID by adding 1 to the last store found
    let warehouse = getWarehouses();
    let lastWH = warehouse[warehouse.length - 1];

    let lastWHId = lastWH.dataset.bakery;

    let nextStoreId = "W" + (Number(lastWHId.substring(1)) + 1);

    return nextStoreId;

}
//not  working
function AddWarehouse() {

    let newWarehouseId = getNextWarehouseId();

    let warehouseHeader = document.createElement("th");
    warehouseHeader.setAttribute("scope", "col");
    warehouseHeader.innerHTML = "Warehouse" + newWarehouseId;

    document.getElementById("colHead").appendChild(warehouseHeader);

    //max product box
    let newBakeryProduction = document.createElement("td");
    newBakeryProduction.innerHTML = "<input type='number' value='800' class='supply' id='supplyB5' data-bakery='B5'>";
    document.getElementById("maxProd").append(newBakeryProduction);

}


function getRoutes() {
    //This function pulls all the routes
    let routes = Array.from(document.getElementsByClassName("route"));
    return routes;
}

function getStores() {
    //This function pulls all the stores
    let stores = Array.from(document.getElementsByClassName("store"));
    return stores;
}

function getBakeries() {
    //This function pulls all the bakeries
    let bakeries = Array.from(document.getElementsByClassName("bakery"));
    return bakeries;
}



function getStoreName(id) {
    //This function returns the store name based on the Id.
    return document.getElementById("store" + id).value;
}

function AddDestination() {
    //Step 2 - Dynamically add more stores
    let newStoreId = getNextStoreId();

    let store = document.createElement("tr");

    //storeHeader
    let storeHeader = document.createElement("th");
    storeHeader.setAttribute("scope", "row");
    storeHeader.innerHTML = "<input type ='text' class='store' id='store" + newStoreId
        + "' data-store='" + newStoreId + "'>"
    store.appendChild(storeHeader);

    //storeDemand
    let storeDemand = document.createElement("td");
    storeDemand.innerHTML = "<input type='number' class='demand' id='demand" +
        newStoreId + "' data-store='" + newStoreId + "'>";
    store.appendChild(storeDemand);


    //bakeries
    let bakeries = getBakeries();
    for (let step = 0; step < bakeries.length; step++) {

        let route = document.createElement("td");
        let bakeryId = bakeries[step].dataset.bakery;
        route.innerHTML = "<input type='number' class='route' id='" + newStoreId +
            bakeryId + "' data-store='" + newStoreId + "' data-bakery='" + bakeryId
            + "'>"

        store.appendChild(route);
    }

    document.getElementById("storesList").append(store);



}

function displayResults(results) {
    //Step 5 - Display the results

    //use unordered list for each bakery, then add the deliveries greater than 0 to list
    let routes = getRoutes();

    for (let step = 0; step < routes.length; step++) {

        let routeId = routes[step].id;
        let bakeryId = routes[step].dataset.bakery;
        let storeId = routes[step].dataset.store;
        let routeAmount = Number(results[routeId].data[0][0]);

        if (routeAmount > 0) {
            let delivery = document.createElement("li");
            delivery.innerHTML = getStoreName(storeId) + " - " + routeAmount;
            document.getElementById("deliveries" + bakeryId).appendChild(delivery);
        }
    }

    //put total for each bakery, look @ results & lookup value for constraints
    let bakeries = getBakeries();
    console.log(bakeries);

    for (let step = 0; step < bakeries.length; step++) {
        let bakeryId = bakeries[step].dataset.bakery;
        document.getElementById("total" + bakeryId).innerHTML = "Total: " +
            (Number(results[bakeryId].data[0][0]));
    }

}

async function Optimize() {
    let apiUrl = 'https://prod-74.eastus.logic.azure.com:443/workflows/3778e31037f34c1e84abc1e6221e5e23/triggers/manual/paths/invoke?api-version=2016-10-01&sp=%2Ftriggers%2Fmanual%2Frun&sv=1.0&sig=K_7ecOlH6o702oziichcB0kOflE0m_ugjl36Cm1q_NI'
    let data = model;

    const response = await fetch(apiUrl, {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json'
        },
        body: JSON.stringify(data)
    });

    const results = await response.json();

    return results;

}

function buildModel() {


    //Variables Step 4
    //get routes as variables
    let variables = getRoutes();

    for (let step = 0; step < variables.length; step++) {

        addVariable(variables[step].id, "lower", 0, true);

    }

    //Constraints Step 4

    //bakeries constriant (supply)
    let bakeryConstraints = getBakeries();

    for (let step = 0; step < bakeryConstraints.length; step++) {

        let bakeryId = bakeryConstraints[step].dataset.bakery;
        let value = document.getElementById("supply" + bakeryId).value

        let relatedRoutes = variables.filter(variable => variable.dataset.bakery == bakeryId);
        let formula = "";
        for (let step = 0; step < relatedRoutes.length; step++) {
            formula += relatedRoutes[step].id;
            if (step !== (relatedRoutes.length - 1)) {
                formula += " + "
            }
        }
        //use upper since always enough supply
        addConstraint(bakeryId, "upper", value, formula);

    }

    //store Constraint (demand)
    let storesConstraints = getStores();

    for (let step = 0; step < storesConstraints.length; step++) {
        let storeId = storesConstraints[step].dataset.store;
        let value = document.getElementById("demand" + storeId).value;

        let relatedRoutes = variables.filter(variable => variable.dataset.store ==
            storeId);
        let formula = "";
        for (let step = 0; step < relatedRoutes.length; step++) {
            formula += relatedRoutes[step].id;
            if (step !== (relatedRoutes.length - 1)) {
                formula += " + "
            }
        }
        addConstraint(storeId, "equal", value, formula);
    }

    //Objective Step 4
    //get all values from input boxes as the coefficient to the variable

    let objformula = "";
    for (let step = 0; step < variables.length; step++) {
        let coef = document.getElementById(variables[step].id).value;
        objformula += coef + " * " + variables[step].id;
        if (step !== (variables.length - 1)) {
            objformula += " + "
        }
    }
    addObjective("minimize", objformula);

}

/* -- HELPER FUNCTIONS --*/
/* -- HELPER FUNCTIONS --*/
/* -- HELPER FUNCTIONS --*/

function CurrencyFormat(number) {
    var formatter = new Intl.NumberFormat('en-US', {
        style: 'currency',
        currency: 'USD'
    });

    return formatter.format(number);
}

function addVariable(name, opperator, value, integer = true) {

    //Build variable
    let variable = {};

    variable.name = name;

    if (opperator == "upper") {
        variable.upper = Number(value);
    } else {
        variable.lower = Number(value);
    }

    //Integer Type    
    if (integer) {
        variable.type = "int";
    }

    //Store Final Value
    variable.finalValue = [];

    //Add variable to MODEL
    if (model.variables === undefined) {
        model.variables = {};
    }

    model.variables[name] = variable;

}

function addConstraint(name, opperator = "upper", value, formula) {
    //Build constraint
    let constraint = {};

    constraint.name = name;

    if (opperator == "upper") {
        constraint.upper = Number(value);
    } else if (opperator == "lower") {
        constraint.lower = Number(value);
    } else {
        constraint.equal = Number(value);
    }

    constraint.formula = formula;

    //Store Final Value
    constraint.finalValue = [];

    //Add variable to MODEL
    if (model.constraints === undefined) {
        model.constraints = {};
    }

    model.constraints[name] = constraint;
}

function addObjective(type = "maximize", formula) {
    //Add objective to MODEL
    model.objective = {};
    model.objective.obj = {};
    model.objective.obj.type = type;
    model.objective.obj.formula = formula;
    model.objective.obj.finalValue = [];
}

